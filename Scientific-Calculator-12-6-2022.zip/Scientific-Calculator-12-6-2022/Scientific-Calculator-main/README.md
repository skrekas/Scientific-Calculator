### Scientific-Calculator

A calculator with several modes (standard, scientific etc.) that is written in Python and tkinter. 
